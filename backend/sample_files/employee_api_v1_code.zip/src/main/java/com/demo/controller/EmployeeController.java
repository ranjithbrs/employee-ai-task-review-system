package com.demo.controller;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/employees")
public class EmployeeController {
    @GetMapping
    public List<Employee> getAll() { return List.of(); }
    @PostMapping
    public Employee create(@RequestBody EmployeeDTO dto) { return new Employee(); }
}
