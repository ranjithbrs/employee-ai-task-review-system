package com.demo.dto;
public class EmployeeDTO {

    private String name;
    private String email;
    
}
