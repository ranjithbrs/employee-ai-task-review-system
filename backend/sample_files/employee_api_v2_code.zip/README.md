# Employee REST API Project
## Endpoints
- GET /api/v1/employees - List all
- POST /api/v1/employees - Create new
- PUT /api/v1/employees/{id} - Update
- DELETE /api/v1/employees/{id} - Delete

## Validation & Error Handling
Centralized validation and exception handling enabled.
